#include <stdio.h>

int main(void)
{
    puts("Hello foobar!\n");

    while(1);
}
