#include <cv.h>

int main ( int argc, char **argv )
{

	printf ("jojo\n");
	
	return 0;
}
