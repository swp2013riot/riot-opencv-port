#ifndef BOARD_CONF_H
#define BOARD_CONF_H 

#define INFOMEM     (0x1000)

#endif /* BOARD-CONF_H */
