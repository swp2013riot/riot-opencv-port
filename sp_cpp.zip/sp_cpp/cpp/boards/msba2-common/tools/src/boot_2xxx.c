/* automatically generated from boot_2xxx.armasm */
#include "boot_2xxx.h"
const unsigned int boot_2xxx[] = {
	7, 0xe28f000c, 0xe5901000, 0xe3a00001, 0xe5810000, 0xe3a0f000, 0xe01fc040
};
