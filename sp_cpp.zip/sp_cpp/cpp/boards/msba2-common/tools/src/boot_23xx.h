/* automatically generated from boot_23xx.armasm */
extern const unsigned int boot_23xx[];
