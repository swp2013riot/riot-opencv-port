extern void uuencode(char *str, const unsigned char *data, int num);
extern int uudecode(const char *str, unsigned char *data, int max);

