
typedef struct {
	int size;
	const int *prog;
} boot_t;




