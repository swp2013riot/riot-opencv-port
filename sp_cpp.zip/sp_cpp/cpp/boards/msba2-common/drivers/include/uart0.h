#ifndef __UART0_H
#define __UART0_H 

#define UART0_BUFSIZE 32

extern int uart0_handler_pid;

#endif /* __UART0_H */
