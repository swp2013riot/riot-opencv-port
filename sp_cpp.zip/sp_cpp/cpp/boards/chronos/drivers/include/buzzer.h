#ifndef BUZZER_H
#define BUZZER_H 

void buzzer_beep(uint8_t pitch, uint16_t duration);

#endif /* BUZZER_H */
