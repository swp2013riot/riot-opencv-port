#ifndef __DISPLAY_PUTCHAR_H
#define __DISPLAY_PUTCHAR_H 

void init_display_putchar(void);

#endif /* __DISPLAY_PUTCHAR_H */
