#ifndef IO_H
#define IO_H

int fw_puts(char* data, int count);

#endif /* IO_H */
