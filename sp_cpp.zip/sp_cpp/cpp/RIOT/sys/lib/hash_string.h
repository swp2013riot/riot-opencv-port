#ifndef __HASH_STRING_H
#define __HASH_STRING_H 

unsigned long hash_string(unsigned char *str);
int cmp_string(char* a, char* b);

#endif /* __HASH_STRING_H */
