#include "objective_functions.h"

void of0(){


}
