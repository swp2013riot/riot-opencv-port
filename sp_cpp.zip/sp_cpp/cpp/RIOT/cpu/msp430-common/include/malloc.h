#ifndef __MALLOC_H
#define __MALLOC_H 

#include "oneway_malloc.h"

#define malloc _malloc
#define realloc _realloc
#define free _free

#endif /* __MALLOC_H */
