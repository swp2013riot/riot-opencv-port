#ifndef BATTERY_H
#define BATTERY_H 

uint32_t battery_get_voltage(void);

#endif /* BATTERY_H */
