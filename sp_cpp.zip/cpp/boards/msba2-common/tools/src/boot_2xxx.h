/* automatically generated from boot_2xxx.armasm */
extern const unsigned int boot_2xxx[];
