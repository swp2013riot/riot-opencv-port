#ifndef CONTROL_2XXXX_H
#define CONTROL_2XXXX_H

void hard_reset_to_bootloader(void);
void hard_reset_to_user_code(void);

#endif // ..._H

