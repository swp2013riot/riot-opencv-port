extern void create_window(int *argc, char ***argv);
extern void run_gui(void);
extern void done_program(int still_in_bootloader);
