Platform configurations for RIOT-OS
====================================
This repository contains existing configuration and initialization files for platforms supported by RIOT-OS.

RIOT's kernel, system libraries, and drivers can be found here:
https://github.com/RIOT-OS/RIOT
