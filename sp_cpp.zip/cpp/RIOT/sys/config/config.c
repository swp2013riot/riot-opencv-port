#include <config.h>

config_t sysconfig  = {
    0,      ///< default ID
    0,      ///< default radio address
    0,      ///< default radio channel
};
