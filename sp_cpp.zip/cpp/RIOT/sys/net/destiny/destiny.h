/*
 * destiny.h
 *
 *  Created on: 03.09.2011
 *      Author: Oliver
 */

#ifndef DESTINY_H_
#define DESTINY_H_

void init_transport_layer(void);

#endif /* DESTINY_H_ */
