#include <stdio.h>

void of0();
