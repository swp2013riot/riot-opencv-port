#include "ps.h"

void _ps_handler(char* unnused) {
    thread_print_all();
}

